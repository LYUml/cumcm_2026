"""Reproduce matched-parameter comparisons and the two Q2 paper figures."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import scipy,sklearn
from q2_near_optimal import read_inputs,run_policy,causal_january_warmup
OUT=ROOT/"02_q2/q2_near_optimal_outputs"
FIG=ROOT/"02_q2/figures"
FIG.mkdir(exist_ok=True)
dates,load,pv,price=read_inputs(ROOT)
net=load-pv
initial=causal_january_warmup(net)
penalties=[4.,4.5,5.,5.5,7.15]
records=[]
cache=OUT/"paper_matched_risk.csv"
old=pd.read_csv(cache) if cache.exists() else pd.DataFrame()
for stage,name in [(24,"Four-hour tree"),(0,"Two-stage relaxation")]:
    saved=pd.concat([pd.read_csv(OUT/f) for f in
        (["comparison_strict4h.csv","comparison_strict4h_fine.csv"] if stage else ["comparison_final.csv"])])
    for penalty in penalties:
        hit=saved[np.isclose(saved.planning_penalty,penalty)]
        if len(hit):
            r=hit.iloc[0].to_dict()
            source="saved verified configuration"
        elif len(old) and len(old[(old.stage_slots==stage)&np.isclose(old.planning_penalty,penalty)]):
            r=old[(old.stage_slots==stage)&np.isclose(old.planning_penalty,penalty)].iloc[0].to_dict()
            source="cached matched run"
        else:
            rows,grids,traces=run_policy(net,price,3000,penalty,load=load,pv=pv,
                scenario_mode="split",initial_soc=initial,tree_stage_slots=stage)
            balance=grids+traces[:,:,3]+traces[:,:,4]-net[31:]/6-traces[:,:,2]-traces[:,:,5]
            assert abs(balance).max()<1e-6
            assert abs(rows[1:,4]-rows[:-1,5]).max()<1e-6
            assert traces[:,:,1].min()>=1200-1e-6 and traces[:,:,1].max()<=10800+1e-6
            assert not np.any((traces[:,:,2]>1e-7)&(traces[:,:,4]>1e-7))
            r=dict(planned_yuan=rows[:,0].sum(),emergency_yuan=rows[:,1].sum(),
                   total_yuan=rows[:,2].sum(),final_soc=rows[-1,5])
            source="new matched run; physical checks passed"
        records.append(dict(method=name,stage_slots=stage,planning_penalty=penalty,
            lambda_weight=penalty/5,planned_yuan=r["planned_yuan"],emergency_yuan=r["emergency_yuan"],
            total_yuan=r["total_yuan"],final_soc=r["final_soc"],source=source))
        pd.DataFrame(records).to_csv(cache,index=False)
        print(name,penalty,r["total_yuan"],flush=True)

plt.rcParams.update({"font.family":"DejaVu Serif","font.size":10,"axes.labelsize":11,
    "axes.titlesize":11,"axes.spines.top":False,"axes.spines.right":False,
    "pdf.fonttype":42,"svg.fonttype":"none","savefig.facecolor":"white"})
blue="#214F73"; orange="#AC632E"
df=pd.DataFrame(records)
fig,ax=plt.subplots(figsize=(7.2,4.1),layout="constrained")
for name,color,marker,style in [("Four-hour tree",blue,"o","-"),("Two-stage relaxation",orange,"s","--")]:
    z=df[df.method==name].sort_values("lambda_weight")
    ax.plot(z.lambda_weight,z.total_yuan/1e6,style,marker=marker,color=color,lw=1.6,
        ms=5,label=name)
ax.set(xlabel=r"Planning shortage weight $\lambda$  (actual emergency tariff fixed at $5p_t$)",
       ylabel="Realized expenditure (million CNY)")
ax.grid(axis="y",color=".88",lw=.6)
ax.legend(frameon=False,loc="best")
ax.set_xticks([.8,.9,1,1.1,1.43])
ax.axvline(1,color=".6",lw=.8,ls=":")
for name,color in [("Four-hour tree",blue),("Two-stage relaxation",orange)]:
    z=df[df.method==name]; r=z.loc[z.total_yuan.idxmin()]
    ax.annotate(f"{r.total_yuan/1e6:.4f}",(r.lambda_weight,r.total_yuan/1e6),
                xytext=((-12,12) if name=="Two-stage relaxation" else (0,-17)),
                textcoords="offset points",ha="center",color=color,fontsize=9)
for ext in ["png","pdf","svg"]: fig.savefig(FIG/f"q2_risk_cost.{ext}",dpi=300)
plt.close(fig)

daily=pd.read_csv(OUT/"best_daily_strict4h_fine.csv")
i=int((daily.total_yuan-daily.total_yuan.median()).abs().idxmin())
policy=np.load(OUT/"best_policy_strict4h_fine.npz")
flow=policy["trace"][i]; grid=policy["grid"][i]
day=i+31
# Slot 0 is 00:10-00:20 under the official-template mapping.
hours=(np.arange(144)+1)/6
fig,(a,b)=plt.subplots(2,1,figsize=(7.2,5.2),sharex=True,layout="constrained",
                       gridspec_kw={"height_ratios":[1.3,1]})
a.step(hours,net[day]/1000,where="post",color=".2",lw=1.25,label="Actual net load")
a.step(hours,grid*6/1000,where="post",color=blue,lw=1.3,label="Committed purchase")
a.fill_between(hours,0,flow[:,4]*6/1000,step="post",color=orange,alpha=.55,label="Emergency purchase")
a.set_ylabel("Interval-average power (MW)")
a.set_title(f"(a) Supply and net load — {daily.iloc[i].date}",loc="left")
a.legend(frameon=False,ncol=3,fontsize=8,loc="upper left")
a.set_ylim(min(-.5,net[day].min()/1000-.5),max(net[day].max()/1000,grid.max()*6/1000)*1.35)
a.text(.985,.87,f"Emergency energy: {flow[:,4].sum():.2f} kWh",transform=a.transAxes,
       ha="right",va="top",fontsize=9,color=orange)
a.grid(axis="y",color=".88",lw=.6)
states=np.r_[flow[0,0],flow[:,1]]/1000
b.plot(np.r_[0,(np.arange(144)+2)/6],states,color=blue,lw=1.5)
b.axhline(1.2,color=".45",lw=.8,ls="--")
b.axhline(10.8,color=".45",lw=.8,ls="--")
b.text(23.7,10.8,"Upper limit",ha="right",va="bottom",fontsize=8,color=".4")
b.text(23.7,1.2,"Lower limit",ha="right",va="bottom",fontsize=8,color=".4")
b.set(xlabel="Time of day",ylabel="Stored energy (MWh)",xlim=(0,24),ylim=(.5,11.8))
b.set_title("(b) Realized storage trajectory",loc="left")
b.set_xticks(np.arange(0,25,4),[f"{h:02d}:00" for h in range(0,25,4)])
b.grid(axis="y",color=".88",lw=.6)
for ext in ["png","pdf","svg"]: fig.savefig(FIG/f"q2_representative_day.{ext}",dpi=300)
plt.close(fig)
meta=dict(date=str(daily.iloc[i].date),selection="closest to median daily total cost; first date breaks ties",
    daily_total_yuan=float(daily.iloc[i].total_yuan),median_daily_cost=float(daily.total_yuan.median()),
    emergency_kwh=float(flow[:,4].sum()),initial_soc=float(flow[0,0]),final_soc=float(flow[-1,1]))
meta["runtime_versions"]={"numpy":np.__version__,"pandas":pd.__version__,
    "scipy":scipy.__version__,"sklearn":sklearn.__version__,"matplotlib":matplotlib.__version__}
(OUT/"paper_figures_metadata.json").write_text(json.dumps(meta,indent=2))
print(json.dumps(meta),flush=True)
